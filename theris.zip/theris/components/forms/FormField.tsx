import { cn } from "@/lib/utils";
import { forwardRef } from "react";

type FieldVariant = "light" | "dark";

type BaseProps = {
  label: string;
  error?: string;
  variant?: FieldVariant;
  className?: string;
};

type InputProps = BaseProps &
  React.InputHTMLAttributes<HTMLInputElement> & {
    as?: "input";
  };

type TextareaProps = BaseProps &
  React.TextareaHTMLAttributes<HTMLTextAreaElement> & {
    as: "textarea";
  };

type SelectProps = BaseProps &
  React.SelectHTMLAttributes<HTMLSelectElement> & {
    as: "select";
    children: React.ReactNode;
  };

type FormFieldProps = InputProps | TextareaProps | SelectProps;

const baseStyles = "w-full bg-transparent border-b py-3 px-0 text-base focus:outline-none transition-colors duration-300";

const variantStyles: Record<FieldVariant, string> = {
  light: "border-ink/30 text-ink placeholder:text-ink/40 focus:border-ink",
  dark: "border-bone/30 text-bone placeholder:text-bone/40 focus:border-brass",
};

const labelVariantStyles: Record<FieldVariant, string> = {
  light: "text-ink/60",
  dark: "text-bone/60",
};

const FormField = forwardRef<
  HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement,
  FormFieldProps
>(({ label, error, variant = "light", className, ...props }, ref) => {
  const id = props.id || props.name;

  const inputClasses = cn(baseStyles, variantStyles[variant], className);

  const renderField = () => {
    if (props.as === "textarea") {
      const { as, ...rest } = props;
      return (
        <textarea
          ref={ref as React.Ref<HTMLTextAreaElement>}
          id={id}
          rows={4}
          className={cn(inputClasses, "resize-none")}
          {...rest}
        />
      );
    }

    if (props.as === "select") {
      const { as, children, ...rest } = props;
      return (
        <select
          ref={ref as React.Ref<HTMLSelectElement>}
          id={id}
          className={cn(inputClasses, "appearance-none cursor-pointer")}
          {...rest}
        >
          {children}
        </select>
      );
    }

    const { as, ...rest } = props as InputProps;
    return (
      <input
        ref={ref as React.Ref<HTMLInputElement>}
        id={id}
        className={inputClasses}
        {...rest}
      />
    );
  };

  return (
    <div className="flex flex-col gap-2">
      <label
        htmlFor={id}
        className={cn(
          "text-xs uppercase tracking-widest font-medium",
          labelVariantStyles[variant],
        )}
      >
        {label}
      </label>
      {renderField()}
      {error && (
        <span className="text-red-400 text-xs mt-1">{error}</span>
      )}
    </div>
  );
});

FormField.displayName = "FormField";

export default FormField;
