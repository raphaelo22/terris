"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import FormField from "./FormField";
import Button from "@/components/ui/Button";
import { CheckCircle2 } from "lucide-react";

const schema = z.object({
  nom: z.string().min(2, "Votre nom"),
  email: z.string().email("Email invalide"),
  telephone: z.string().min(8, "Numéro de téléphone"),
  message: z.string().min(10, "Décrivez votre demande en quelques mots"),
  bienRef: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

type ContactFormProps = {
  variant?: "light" | "dark";
  bienRef?: string;
  defaultMessage?: string;
};

export default function ContactForm({
  variant = "light",
  bienRef,
  defaultMessage,
}: ContactFormProps) {
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      bienRef,
      message: defaultMessage,
    },
  });

  const onSubmit = async (data: FormValues) => {
    setSubmitting(true);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Erreur d'envoi");
      setSubmitted(true);
      reset();
    } catch (error) {
      alert("Une erreur est survenue. Réessayez ou contactez-nous directement.");
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div
        className={`flex flex-col items-start gap-4 p-8 ${
          variant === "dark"
            ? "border border-brass/30 bg-bone/5"
            : "border border-ink/15 bg-cream/40"
        }`}
      >
        <CheckCircle2
          size={32}
          className={variant === "dark" ? "text-brass" : "text-ink"}
        />
        <h3
          className={`font-serif text-2xl ${
            variant === "dark" ? "text-bone" : "text-ink"
          }`}
        >
          Message envoyé.
        </h3>
        <p className={variant === "dark" ? "text-mist" : "text-ink/70"}>
          On vous répond rapidement, généralement sous 24h ouvrables.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
      {bienRef && (
        <input type="hidden" {...register("bienRef")} value={bienRef} />
      )}

      <FormField
        label="Nom complet"
        variant={variant}
        {...register("nom")}
        error={errors.nom?.message}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          label="Email"
          variant={variant}
          type="email"
          {...register("email")}
          error={errors.email?.message}
        />
        <FormField
          label="Téléphone"
          variant={variant}
          type="tel"
          {...register("telephone")}
          error={errors.telephone?.message}
        />
      </div>

      <FormField
        as="textarea"
        label="Message"
        variant={variant}
        placeholder="Votre message..."
        {...register("message")}
        error={errors.message?.message}
      />

      <div className="pt-4">
        <Button
          type="submit"
          variant={variant === "dark" ? "outline-light" : "primary"}
          icon
          className={submitting ? "opacity-60 cursor-wait" : ""}
        >
          {submitting ? "Envoi…" : "Envoyer le message"}
        </Button>
      </div>
    </form>
  );
}
