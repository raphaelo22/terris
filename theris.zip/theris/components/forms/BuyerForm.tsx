"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import FormField from "./FormField";
import Button from "@/components/ui/Button";
import { CheckCircle2 } from "lucide-react";

const schema = z.object({
  prenom: z.string().min(2, "Votre prénom"),
  email: z.string().email("Email invalide"),
  telephone: z.string().min(8, "Numéro de téléphone"),
  budget: z.string().min(1, "Sélectionnez un budget"),
  epargne: z.string().min(1, "Sélectionnez une épargne disponible"),
  typeRecherche: z.string().min(1, "Type de bien recherché"),
  zoneRecherche: z.string().min(2, "Zone géographique"),
  timeline: z.string().min(1, "Sélectionnez votre timeline"),
  message: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

type BuyerFormProps = {
  variant?: "light" | "dark";
};

export default function BuyerForm({ variant = "light" }: BuyerFormProps) {
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: FormValues) => {
    setSubmitting(true);
    try {
      const res = await fetch("/api/acheteur", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Erreur d'envoi");
      setSubmitted(true);
      reset();
    } catch (error) {
      alert("Une erreur est survenue. Réessayez ou contactez-nous directement.");
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div
        className={`flex flex-col items-start gap-4 p-8 ${
          variant === "dark"
            ? "border border-brass/30 bg-bone/5"
            : "border border-ink/15 bg-cream/40"
        }`}
      >
        <CheckCircle2
          size={32}
          className={variant === "dark" ? "text-brass" : "text-ink"}
        />
        <h3
          className={`font-serif text-2xl ${
            variant === "dark" ? "text-bone" : "text-ink"
          }`}
        >
          Message reçu.
        </h3>
        <p
          className={
            variant === "dark" ? "text-mist" : "text-ink/70"
          }
        >
          On revient vers vous sous 24h ouvrables avec une première sélection
          ou un échange téléphonique.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          label="Prénom"
          variant={variant}
          {...register("prenom")}
          error={errors.prenom?.message}
        />
        <FormField
          label="Téléphone"
          variant={variant}
          type="tel"
          {...register("telephone")}
          error={errors.telephone?.message}
        />
      </div>

      <FormField
        label="Email"
        variant={variant}
        type="email"
        {...register("email")}
        error={errors.email?.message}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          as="select"
          label="Budget"
          variant={variant}
          {...register("budget")}
          error={errors.budget?.message}
        >
          <option value="">Sélectionnez</option>
          <option value="< 300k€">Moins de 300 000 €</option>
          <option value="300-500k€">300 000 € — 500 000 €</option>
          <option value="500-750k€">500 000 € — 750 000 €</option>
          <option value="750k-1M€">750 000 € — 1 000 000 €</option>
          <option value="> 1M€">Plus de 1 000 000 €</option>
        </FormField>

        <FormField
          as="select"
          label="Épargne disponible"
          variant={variant}
          {...register("epargne")}
          error={errors.epargne?.message}
        >
          <option value="">Sélectionnez</option>
          <option value="< 30k€">Moins de 30 000 €</option>
          <option value="30-60k€">30 000 € — 60 000 €</option>
          <option value="60-100k€">60 000 € — 100 000 €</option>
          <option value="> 100k€">Plus de 100 000 €</option>
        </FormField>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          as="select"
          label="Type de bien"
          variant={variant}
          {...register("typeRecherche")}
          error={errors.typeRecherche?.message}
        >
          <option value="">Sélectionnez</option>
          <option value="maison">Maison</option>
          <option value="appartement">Appartement</option>
          <option value="terrain">Terrain</option>
          <option value="immeuble">Immeuble de rapport</option>
          <option value="peu importe">Je suis ouvert(e)</option>
        </FormField>

        <FormField
          label="Zone souhaitée"
          variant={variant}
          placeholder="Ixelles, Uccle, Brabant Wallon..."
          {...register("zoneRecherche")}
          error={errors.zoneRecherche?.message}
        />
      </div>

      <FormField
        as="select"
        label="Timeline"
        variant={variant}
        {...register("timeline")}
        error={errors.timeline?.message}
      >
        <option value="">Sélectionnez</option>
        <option value="urgent">Urgent (1-2 mois)</option>
        <option value="3 mois">D'ici 3 mois</option>
        <option value="6 mois">D'ici 6 mois</option>
        <option value="je regarde">Je regarde, sans urgence</option>
      </FormField>

      <FormField
        as="textarea"
        label="Message (optionnel)"
        variant={variant}
        placeholder="Précisez votre projet, vos critères ou questions..."
        {...register("message")}
        error={errors.message?.message}
      />

      <div className="pt-4">
        <Button
          type="submit"
          variant={variant === "dark" ? "outline-light" : "primary"}
          icon
          className={submitting ? "opacity-60 cursor-wait" : ""}
        >
          {submitting ? "Envoi…" : "Envoyer ma demande"}
        </Button>
      </div>
    </form>
  );
}
