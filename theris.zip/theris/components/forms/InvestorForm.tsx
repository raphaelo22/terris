"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import FormField from "./FormField";
import Button from "@/components/ui/Button";
import { CheckCircle2 } from "lucide-react";

const schema = z.object({
  prenom: z.string().min(2, "Votre prénom"),
  email: z.string().email("Email invalide"),
  telephone: z.string().min(8, "Numéro de téléphone"),
  montant: z.string().min(1, "Sélectionnez un montant"),
  objectif: z.string().min(1, "Sélectionnez un objectif"),
  profil: z.string().min(1, "Sélectionnez votre profil"),
  message: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

type InvestorFormProps = {
  variant?: "light" | "dark";
};

export default function InvestorForm({ variant = "light" }: InvestorFormProps) {
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: FormValues) => {
    setSubmitting(true);
    try {
      const res = await fetch("/api/investisseur", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Erreur d'envoi");
      setSubmitted(true);
      reset();
    } catch (error) {
      alert("Une erreur est survenue. Réessayez ou contactez-nous directement.");
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div
        className={`flex flex-col items-start gap-4 p-8 ${
          variant === "dark"
            ? "border border-brass/30 bg-bone/5"
            : "border border-ink/15 bg-cream/40"
        }`}
      >
        <CheckCircle2
          size={32}
          className={variant === "dark" ? "text-brass" : "text-ink"}
        />
        <h3
          className={`font-serif text-2xl ${
            variant === "dark" ? "text-bone" : "text-ink"
          }`}
        >
          Demande reçue.
        </h3>
        <p className={variant === "dark" ? "text-mist" : "text-ink/70"}>
          Nous vous contactons sous 48h ouvrables pour échanger sur votre
          stratégie d'investissement.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          label="Prénom"
          variant={variant}
          {...register("prenom")}
          error={errors.prenom?.message}
        />
        <FormField
          label="Téléphone"
          variant={variant}
          type="tel"
          {...register("telephone")}
          error={errors.telephone?.message}
        />
      </div>

      <FormField
        label="Email"
        variant={variant}
        type="email"
        {...register("email")}
        error={errors.email?.message}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          as="select"
          label="Capacité d'investissement"
          variant={variant}
          {...register("montant")}
          error={errors.montant?.message}
        >
          <option value="">Sélectionnez</option>
          <option value="< 100k€">Moins de 100 000 €</option>
          <option value="100-250k€">100 000 € — 250 000 €</option>
          <option value="250-500k€">250 000 € — 500 000 €</option>
          <option value="500k-1M€">500 000 € — 1 000 000 €</option>
          <option value="> 1M€">Plus de 1 000 000 €</option>
        </FormField>

        <FormField
          as="select"
          label="Profil"
          variant={variant}
          {...register("profil")}
          error={errors.profil?.message}
        >
          <option value="">Sélectionnez</option>
          <option value="particulier">Particulier</option>
          <option value="société">Société</option>
          <option value="famille">Cellule familiale</option>
        </FormField>
      </div>

      <FormField
        as="select"
        label="Objectif"
        variant={variant}
        {...register("objectif")}
        error={errors.objectif?.message}
      >
        <option value="">Sélectionnez</option>
        <option value="achat-revente">Plus-value (achat-revente)</option>
        <option value="locatif">Rendement locatif</option>
        <option value="airbnb">Court terme / Airbnb</option>
        <option value="diversifier">Je veux diversifier</option>
      </FormField>

      <FormField
        as="textarea"
        label="Message (optionnel)"
        variant={variant}
        placeholder="Votre horizon, vos contraintes, vos questions..."
        {...register("message")}
        error={errors.message?.message}
      />

      <div className="pt-4">
        <Button
          type="submit"
          variant={variant === "dark" ? "outline-light" : "primary"}
          icon
          className={submitting ? "opacity-60 cursor-wait" : ""}
        >
          {submitting ? "Envoi…" : "Devenir investisseur partenaire"}
        </Button>
      </div>
    </form>
  );
}
