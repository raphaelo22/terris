"use client";

import { motion } from "framer-motion";

export default function Quote() {
  return (
    <section className="bg-bone py-32 md:py-40 container-px">
      <div className="max-w-5xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
        >
          <span
            className="font-serif text-brass text-7xl md:text-8xl leading-none"
            aria-hidden="true"
          >
            "
          </span>
          <blockquote className="mt-4 font-serif text-3xl md:text-5xl lg:text-6xl text-ink italic leading-[1.2]">
            On ne lâche jamais un client avant la remise des clés.
            <br />
            <span className="not-italic">Et souvent au-delà.</span>
          </blockquote>
          <div className="mt-12 flex flex-col items-center gap-2">
            <span className="block w-12 h-px bg-brass" />
            <span className="eyebrow text-ink/60">L'équipe Théris</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
