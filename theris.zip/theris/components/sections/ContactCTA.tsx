"use client";

import { motion } from "framer-motion";
import BuyerForm from "@/components/forms/BuyerForm";

export default function ContactCTA() {
  return (
    <section className="bg-ink text-bone py-24 md:py-32 container-px">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 space-y-6"
          >
            <span className="eyebrow-brass">Parlons de votre projet</span>
            <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl leading-[1.1]">
              Dites-nous ce que vous cherchez.
            </h2>
            <p className="text-mist leading-relaxed text-lg">
              Quelques informations suffisent pour qu'on vous recontacte
              avec des biens qui correspondent à votre projet — ou pour
              vous prévenir dès qu'une opportunité émerge.
            </p>
            <div className="pt-6 space-y-2 text-mist">
              <p className="text-sm">Vous préférez parler directement ?</p>
              <a
                href="tel:+32000000000"
                className="block text-bone text-xl hover:text-brass transition-colors"
              >
                +32 (0)0 00 00 00 00
              </a>
              <a
                href="mailto:contact@theris.be"
                className="block text-bone hover:text-brass transition-colors"
              >
                contact@theris.be
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <BuyerForm variant="dark" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
