"use client";

import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import Link from "next/link";
import PropertyCard from "@/components/ui/PropertyCard";
import type { Bien } from "@/lib/types";

type Props = {
  biens: Bien[];
};

export default function FeaturedProperties({ biens }: Props) {
  return (
    <section className="bg-ink text-bone py-24 md:py-32 container-px">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16"
        >
          <div className="max-w-2xl">
            <span className="eyebrow-brass">Sélection actuelle</span>
            <h2 className="mt-6 font-serif text-4xl md:text-5xl lg:text-6xl leading-[1.1]">
              Les biens disponibles aujourd'hui.
            </h2>
          </div>
          <Link
            href="/biens"
            className="group inline-flex items-center gap-3 text-brass text-sm uppercase tracking-widest hover:gap-5 transition-all duration-500"
          >
            Voir tous les biens
            <ArrowRight size={16} />
          </Link>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
          {biens.map((bien, index) => (
            <motion.div
              key={bien.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{
                duration: 0.8,
                delay: index * 0.15,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              <PropertyCard bien={bien} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
