"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import Button from "@/components/ui/Button";

const cards = [
  {
    label: "Achat / Revente",
    description:
      "Co-investir sur des biens à valoriser. Votre capital travaille sur des projets concrets, avec une stratégie claire de sortie.",
  },
  {
    label: "Locatif premium",
    description:
      "Acquérir un bien rénové, prêt à louer. Théris peut gérer la location pour vous, ou vous accompagner dans la mise en location.",
  },
  {
    label: "Court terme / Airbnb",
    description:
      "Investir sur des biens optimisés pour la location courte durée. Décoration, mise en marché et gestion incluses.",
  },
];

export default function InvestorSection() {
  return (
    <section className="bg-midnight text-bone py-24 md:py-32 container-px overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 relative aspect-[4/5] overflow-hidden"
          >
            <Image
              src="https://images.unsplash.com/photo-1582407947304-fd86f028f716?w=1600&q=80"
              alt="Investir avec Théris"
              fill
              sizes="(max-width: 1024px) 100vw, 40vw"
              className="object-cover"
            />
            <div className="absolute inset-0 bg-ink/30" />
          </motion.div>

          {/* Contenu */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 space-y-10"
          >
            <div>
              <span className="eyebrow-brass">Investisseurs</span>
              <h2 className="mt-6 font-serif text-4xl md:text-5xl lg:text-6xl leading-[1.1]">
                Trois façons d'investir avec nous.
              </h2>
              <p className="mt-6 text-mist text-lg leading-relaxed max-w-2xl">
                Chez Théris, l'investissement immobilier ne se résume pas à
                signer un acte. On co-construit votre stratégie selon votre
                profil, vos objectifs et votre horizon.
              </p>
            </div>

            <div className="space-y-5">
              {cards.map((card, index) => (
                <motion.div
                  key={card.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{
                    duration: 0.6,
                    delay: 0.3 + index * 0.1,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  className="group flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-3 sm:gap-8 border-t border-bone/10 pt-5 hover:border-brass transition-colors duration-500"
                >
                  <h3 className="font-serif text-2xl text-bone group-hover:text-brass transition-colors duration-500 sm:flex-shrink-0 sm:w-1/3">
                    {card.label}
                  </h3>
                  <p className="text-mist leading-relaxed flex-1">
                    {card.description}
                  </p>
                </motion.div>
              ))}
            </div>

            <div className="pt-4">
              <Button
                href="/investisseurs"
                variant="outline-light"
                icon
              >
                Devenir investisseur partenaire
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
