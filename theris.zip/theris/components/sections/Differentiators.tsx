"use client";

import { motion } from "framer-motion";

const items = [
  {
    number: "01",
    title: "Nos biens, pas ceux des autres",
    description:
      "Chaque bien sur ce site nous appartient. Pas d'intermédiaire, pas de mandat, pas de double jeu. Vous traitez directement avec le propriétaire.",
  },
  {
    number: "02",
    title: "Rénovation maîtrisée",
    description:
      "Nous sélectionnons des biens à fort potentiel et les rénovons avec exigence. Volumes, matériaux, finitions — tout est pensé pour durer.",
  },
  {
    number: "03",
    title: "Accompagnement complet",
    description:
      "Crédit, notaire, travaux complémentaires, suivi. On reste à vos côtés jusqu'à la remise des clés. Et souvent au-delà.",
  },
];

export default function Differentiators() {
  return (
    <section className="bg-bone py-24 md:py-32 container-px">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-3xl mb-20"
        >
          <span className="eyebrow-brass">Pourquoi Théris</span>
          <h2 className="mt-6 font-serif text-4xl md:text-5xl lg:text-6xl text-ink leading-[1.1]">
            Trois différences qui changent tout.
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8 lg:gap-16">
          {items.map((item, index) => (
            <motion.div
              key={item.number}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{
                duration: 0.8,
                delay: index * 0.15,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="space-y-6 border-t border-ink/15 pt-8"
            >
              <span className="font-serif text-2xl text-brass">
                {item.number}
              </span>
              <h3 className="font-serif text-2xl md:text-3xl text-ink leading-tight">
                {item.title}
              </h3>
              <p className="text-ink/70 leading-relaxed">
                {item.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
