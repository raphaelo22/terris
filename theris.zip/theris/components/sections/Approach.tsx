"use client";

import { motion } from "framer-motion";

const steps = [
  {
    number: "01",
    title: "Sélection",
    description:
      "Nous identifions des biens à fort potentiel — emplacement, structure, opportunité de valorisation. Ce que vous voyez sur le site, c'est notre sélection.",
  },
  {
    number: "02",
    title: "Rénovation",
    description:
      "Travaux maîtrisés, matériaux choisis, finitions soignées. Quand le bien arrive sur le site, il est prêt à vivre — pas un chantier déguisé.",
  },
  {
    number: "03",
    title: "Présentation",
    description:
      "Visite guidée du bien dans ses moindres détails. Pas d'agent commercial pressé, pas de discours commercial. La transparence sur ce qui a été fait, et ce qui reste.",
  },
  {
    number: "04",
    title: "Accompagnement",
    description:
      "Crédit, notaire, travaux complémentaires, déménagement. On vous met en relation avec des partenaires de confiance et on suit chaque étape avec vous.",
  },
];

export default function Approach() {
  return (
    <section className="bg-bone py-24 md:py-32 container-px">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20">
          {/* Colonne gauche : titre */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 lg:sticky lg:top-32 lg:self-start"
          >
            <span className="eyebrow-brass">Notre approche</span>
            <h2 className="mt-6 font-serif text-4xl md:text-5xl lg:text-6xl text-ink leading-[1.1]">
              Du bien brut à la <span className="italic">remise des clés.</span>
            </h2>
            <p className="mt-8 text-ink/70 leading-relaxed text-lg max-w-md">
              15 ans à acheter, rénover, accompagner. Une méthode rodée
              qui élimine les surprises — celles qu'on aime, comme celles
              qu'on évite.
            </p>
          </motion.div>

          {/* Colonne droite : étapes */}
          <div className="lg:col-span-7 space-y-12">
            {steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{
                  duration: 0.8,
                  delay: index * 0.1,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="border-t border-ink/15 pt-8 grid grid-cols-12 gap-6"
              >
                <span className="col-span-2 font-serif text-2xl text-brass">
                  {step.number}
                </span>
                <div className="col-span-10 space-y-3">
                  <h3 className="font-serif text-2xl md:text-3xl text-ink">
                    {step.title}
                  </h3>
                  <p className="text-ink/70 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
