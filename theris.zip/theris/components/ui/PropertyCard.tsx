import Link from "next/link";
import Image from "next/image";
import type { Bien } from "@/lib/types";
import { formatPrice, formatSurface } from "@/lib/utils";
import { cn } from "@/lib/utils";

type PropertyCardProps = {
  bien: Bien;
  variant?: "light" | "dark";
};

export default function PropertyCard({
  bien,
  variant = "dark",
}: PropertyCardProps) {
  const isLight = variant === "light";

  return (
    <Link
      href={`/biens/${bien.slug}`}
      className="group block"
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-midnight">
        {bien.photos[0] && (
          <Image
            src={bien.photos[0]}
            alt={bien.titre}
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1280px) 50vw, 33vw"
            className="object-cover transition-transform duration-[1.2s] ease-smooth-out group-hover:scale-105"
          />
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/10 to-transparent" />

        {bien.statut !== "disponible" && (
          <span className="absolute top-5 left-5 bg-ink/80 backdrop-blur-sm text-bone text-[0.65rem] uppercase tracking-widest px-3 py-1.5">
            {bien.statut === "reserve" ? "Réservé" : "Vendu"}
          </span>
        )}

        <div className="absolute bottom-0 left-0 right-0 p-6 text-bone">
          <span className="eyebrow text-brass">{bien.ville}</span>
          <h3 className="mt-2 font-serif text-2xl leading-tight">
            {bien.titre}
          </h3>
        </div>
      </div>

      <div
        className={cn(
          "flex items-baseline justify-between pt-5",
          isLight ? "text-ink" : "text-bone",
        )}
      >
        <div className="flex gap-5 text-sm text-mist">
          <span>{formatSurface(bien.surface)}</span>
          {bien.chambres && <span>{bien.chambres} ch.</span>}
          <span className="capitalize">{bien.type}</span>
        </div>
        <span className="font-serif text-xl">{formatPrice(bien.prix)}</span>
      </div>
    </Link>
  );
}
