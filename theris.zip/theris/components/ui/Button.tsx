import Link from "next/link";
import { cn } from "@/lib/utils";
import { ArrowRight } from "lucide-react";

type ButtonVariant = "primary" | "secondary" | "ghost" | "outline-light";

type ButtonProps = {
  href?: string;
  onClick?: () => void;
  variant?: ButtonVariant;
  className?: string;
  children: React.ReactNode;
  icon?: boolean;
  type?: "button" | "submit" | "reset";
};

const variants: Record<ButtonVariant, string> = {
  primary:
    "bg-ink text-bone hover:bg-midnight border border-ink hover:border-midnight",
  secondary:
    "bg-bone text-ink hover:bg-cream border border-ink/10",
  ghost:
    "bg-transparent text-ink border border-ink/30 hover:border-ink hover:bg-ink hover:text-bone",
  "outline-light":
    "bg-transparent text-bone border border-bone/40 hover:border-brass hover:text-brass",
};

export default function Button({
  href,
  onClick,
  variant = "primary",
  className,
  children,
  icon = false,
  type = "button",
}: ButtonProps) {
  const baseClasses = cn(
    "group inline-flex items-center justify-center gap-3 px-7 py-4 text-sm uppercase tracking-widest font-medium transition-all duration-500 ease-smooth-out",
    variants[variant],
    className,
  );

  const content = (
    <>
      <span>{children}</span>
      {icon && (
        <ArrowRight
          size={16}
          className="transition-transform duration-500 ease-smooth-out group-hover:translate-x-1"
        />
      )}
    </>
  );

  if (href) {
    return (
      <Link href={href} className={baseClasses}>
        {content}
      </Link>
    );
  }

  return (
    <button onClick={onClick} type={type} className={baseClasses}>
      {content}
    </button>
  );
}
