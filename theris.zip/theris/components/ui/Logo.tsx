import Link from "next/link";
import { cn } from "@/lib/utils";

type LogoProps = {
  variant?: "light" | "dark";
  className?: string;
  href?: string;
};

export default function Logo({
  variant = "dark",
  className,
  href = "/",
}: LogoProps) {
  const colorClass = variant === "light" ? "text-bone" : "text-ink";

  const content = (
    <div
      className={cn(
        "flex flex-col items-start leading-none select-none",
        colorClass,
        className,
      )}
    >
      <span className="font-serif text-2xl tracking-[0.3em] font-light">
        TERRIS
      </span>
      <span className="text-[0.55rem] tracking-[0.3em] opacity-70 mt-1">
        IMMOBILIER · TERRAIN · INVESTISSEMENT
      </span>
    </div>
  );

  if (href) {
    return (
      <Link href={href} aria-label="Théris — accueil">
        {content}
      </Link>
    );
  }

  return content;
}
