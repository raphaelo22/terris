"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import Logo from "@/components/ui/Logo";

const links = [
  { href: "/biens", label: "Nos biens" },
  { href: "/investisseurs", label: "Investir" },
  { href: "/notre-approche", label: "Notre approche" },
  { href: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (open) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-smooth-out",
        scrolled || open
          ? "bg-ink/95 backdrop-blur-md border-b border-bone/10"
          : "bg-transparent",
      )}
    >
      <div className="container-px flex items-center justify-between h-20">
        <Logo variant="light" />

        <nav className="hidden lg:flex items-center gap-10">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-bone/80 hover:text-brass text-sm uppercase tracking-widest transition-colors duration-300"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <Link
          href="/contact"
          className="hidden lg:inline-flex items-center px-6 py-3 border border-brass text-brass hover:bg-brass hover:text-ink text-xs uppercase tracking-widest transition-all duration-500"
        >
          Estimer mon projet
        </Link>

        <button
          aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
          className="lg:hidden text-bone p-2"
          onClick={() => setOpen(!open)}
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Menu mobile */}
      <div
        className={cn(
          "lg:hidden fixed inset-x-0 top-20 bottom-0 bg-ink transition-transform duration-500 ease-smooth-out",
          open ? "translate-x-0" : "translate-x-full",
        )}
      >
        <nav className="flex flex-col container-px pt-12 gap-8">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="text-bone font-serif text-3xl"
            >
              {link.label}
            </Link>
          ))}
          <Link
            href="/contact"
            onClick={() => setOpen(false)}
            className="mt-8 inline-flex w-fit items-center px-6 py-4 border border-brass text-brass text-xs uppercase tracking-widest"
          >
            Estimer mon projet
          </Link>
        </nav>
      </div>
    </header>
  );
}
