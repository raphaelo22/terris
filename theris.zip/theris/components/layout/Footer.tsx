import Link from "next/link";
import Logo from "@/components/ui/Logo";

const navLinks = [
  { href: "/biens", label: "Nos biens" },
  { href: "/investisseurs", label: "Investir" },
  { href: "/notre-approche", label: "Notre approche" },
  { href: "/contact", label: "Contact" },
];

export default function Footer() {
  return (
    <footer className="bg-ink text-bone border-t border-bone/10">
      <div className="container-px py-20">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-2 space-y-6">
            <Logo variant="light" href="" />
            <p className="text-mist max-w-md leading-relaxed">
              Théris achète, rénove et vous vend ses propres biens.
              Accompagnement complet jusqu'à la remise des clés.
            </p>
          </div>

          <div className="space-y-5">
            <h4 className="eyebrow text-brass">Navigation</h4>
            <ul className="space-y-3">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-bone/80 hover:text-brass transition-colors duration-300 text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-5">
            <h4 className="eyebrow text-brass">Contact</h4>
            <ul className="space-y-3 text-sm text-bone/80">
              <li>
                <a
                  href="mailto:contact@theris.be"
                  className="hover:text-brass transition-colors"
                >
                  contact@theris.be
                </a>
              </li>
              <li>
                <a
                  href="tel:+32000000000"
                  className="hover:text-brass transition-colors"
                >
                  +32 (0)0 00 00 00 00
                </a>
              </li>
              <li className="pt-2">Bruxelles, Belgique</li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-bone/10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <p className="text-xs text-mist">
            © {new Date().getFullYear()} Théris. Tous droits réservés.
          </p>
          <div className="flex gap-6 text-xs text-mist">
            <Link href="/mentions-legales" className="hover:text-brass">
              Mentions légales
            </Link>
            <Link href="/confidentialite" className="hover:text-brass">
              Confidentialité
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
