export type BienStatus = "disponible" | "reserve" | "vendu";

export type BienType = "maison" | "appartement" | "terrain" | "immeuble";

export type Bien = {
  id: string;
  slug: string;
  titre: string;
  type: BienType;
  ville: string;
  prix: number;
  surface: number;
  chambres?: number;
  sallesDeBain?: number;
  description: string;
  caracteristiques: string[];
  photos: string[];
  statut: BienStatus;
  miseEnAvant?: boolean;
  createdAt: string;
};

export type AcheteurLead = {
  prenom: string;
  email: string;
  telephone: string;
  budget: string;
  epargne: string;
  typeRecherche: string;
  zoneRecherche: string;
  timeline: string;
  message?: string;
};

export type InvestisseurLead = {
  prenom: string;
  email: string;
  telephone: string;
  montant: string;
  objectif: string;
  profil: string;
  message?: string;
};

export type ContactLead = {
  nom: string;
  email: string;
  telephone: string;
  message: string;
};
