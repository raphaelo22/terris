import biensData from "@/data/biens.json";
import type { Bien } from "./types";

export function getAllBiens(): Bien[] {
  return biensData as Bien[];
}

export function getBienBySlug(slug: string): Bien | undefined {
  return getAllBiens().find((b) => b.slug === slug);
}

export function getFeaturedBiens(limit = 3): Bien[] {
  return getAllBiens()
    .filter((b) => b.miseEnAvant && b.statut !== "vendu")
    .slice(0, limit);
}

export function getDisponiblesBiens(): Bien[] {
  return getAllBiens().filter((b) => b.statut === "disponible");
}
