import { Resend } from "resend";

const resend = process.env.RESEND_API_KEY
  ? new Resend(process.env.RESEND_API_KEY)
  : null;

type SendEmailParams = {
  subject: string;
  html: string;
  replyTo?: string;
};

export async function sendLeadEmail({
  subject,
  html,
  replyTo,
}: SendEmailParams) {
  const to = process.env.EMAIL_TO || "contact@theris.be";
  const from = process.env.EMAIL_FROM || "site@theris.be";

  if (!resend) {
    // Mode développement : on log dans la console au lieu d'envoyer
    console.log("📧 Email (Resend non configuré):");
    console.log("To:", to);
    console.log("Subject:", subject);
    console.log("HTML:", html);
    return { success: true, dev: true };
  }

  try {
    const { data, error } = await resend.emails.send({
      from,
      to,
      replyTo,
      subject,
      html,
    });

    if (error) {
      console.error("Erreur Resend:", error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (err) {
    console.error("Erreur envoi email:", err);
    return { success: false, error: err };
  }
}

export function formatLeadHtml(
  title: string,
  fields: Record<string, string | undefined>,
): string {
  const rows = Object.entries(fields)
    .filter(([_, value]) => value)
    .map(
      ([key, value]) =>
        `<tr><td style="padding:8px 12px;border-bottom:1px solid #eee;font-weight:600;width:200px;text-transform:uppercase;font-size:11px;letter-spacing:1px;color:#666;">${key}</td><td style="padding:8px 12px;border-bottom:1px solid #eee;">${value}</td></tr>`,
    )
    .join("");

  return `
    <div style="font-family:-apple-system,system-ui,sans-serif;max-width:600px;margin:0 auto;padding:32px;background:#F5F1EA;">
      <h1 style="font-family:Georgia,serif;color:#0A1628;font-size:24px;margin:0 0 8px 0;">${title}</h1>
      <p style="color:#666;margin:0 0 24px 0;font-size:14px;">Nouveau contact reçu via theris.be</p>
      <table style="width:100%;border-collapse:collapse;background:white;">
        ${rows}
      </table>
      <p style="color:#999;margin:24px 0 0 0;font-size:12px;">Théris · ${new Date().toLocaleString("fr-BE")}</p>
    </div>
  `;
}
