import Hero from "@/components/sections/Hero";
import Differentiators from "@/components/sections/Differentiators";
import FeaturedProperties from "@/components/sections/FeaturedProperties";
import Approach from "@/components/sections/Approach";
import InvestorSection from "@/components/sections/InvestorSection";
import Quote from "@/components/sections/Quote";
import ContactCTA from "@/components/sections/ContactCTA";
import { getFeaturedBiens } from "@/lib/biens";

export default function HomePage() {
  const featured = getFeaturedBiens(3);

  return (
    <>
      <Hero />
      <Differentiators />
      <FeaturedProperties biens={featured} />
      <Approach />
      <InvestorSection />
      <Quote />
      <ContactCTA />
    </>
  );
}
