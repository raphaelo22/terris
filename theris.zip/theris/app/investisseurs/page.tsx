import type { Metadata } from "next";
import Image from "next/image";
import InvestorForm from "@/components/forms/InvestorForm";

export const metadata: Metadata = {
  title: "Investir avec Théris · Marchand de biens",
  description:
    "Co-investir, locatif premium, court terme : trois façons de faire travailler votre capital avec Théris en Belgique.",
};

const ways = [
  {
    title: "Achat / Revente",
    description:
      "Vous co-investissez sur des biens à fort potentiel de valorisation. Théris pilote la rénovation et la sortie. Stratégie claire, horizon défini, marge partagée.",
    detail: "Horizon : 12-24 mois · Ticket d'entrée variable",
  },
  {
    title: "Locatif premium",
    description:
      "Vous achetez un bien rénové, prêt à louer. Théris peut prendre en charge la mise en location et la gestion locative. Vous percevez un revenu régulier sans vous occuper du quotidien.",
    detail: "Rendement net visé selon bien · Gestion incluse en option",
  },
  {
    title: "Court terme · Airbnb",
    description:
      "Vous investissez sur un bien optimisé pour la location courte durée. Décoration, équipement, mise en marché et gestion sont assurés par notre équipe.",
    detail: "Rotation rapide · Saisons à exploiter",
  },
];

const reasons = [
  "15 ans d'expérience terrain",
  "Réseau de partenaires solide (notaires, banques, artisans)",
  "Sélection rigoureuse des opportunités",
  "Transparence sur les marges et les coûts",
  "Suivi régulier et reporting clair",
  "Engagement humain, pas seulement financier",
];

export default function InvestorsPage() {
  return (
    <>
      {/* Hero */}
      <section className="relative bg-ink text-bone pt-40 pb-24 container-px overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage:
                "url(https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=2400&q=80)",
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-transparent" />
        </div>

        <div className="relative max-w-7xl mx-auto">
          <span className="eyebrow-brass">Investisseurs</span>
          <h1 className="mt-6 font-serif text-5xl md:text-6xl lg:text-7xl leading-[1.05] max-w-4xl">
            Faites travailler votre capital
            <br />
            <span className="italic">sur des projets réels.</span>
          </h1>
          <p className="mt-8 text-mist text-lg leading-relaxed max-w-2xl">
            Investir avec Théris, c'est choisir un partenaire qui possède,
            rénove et opère ses propres biens. Pas de produit financier
            opaque — des immeubles tangibles, des chantiers concrets, des
            marges expliquées.
          </p>
        </div>
      </section>

      {/* 3 façons */}
      <section className="bg-bone py-24 md:py-32 container-px">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mb-20">
            <span className="eyebrow-brass">Trois façons d'investir</span>
            <h2 className="mt-6 font-serif text-4xl md:text-5xl lg:text-6xl text-ink leading-[1.1]">
              Choisissez l'angle qui vous correspond.
            </h2>
          </div>

          <div className="space-y-12">
            {ways.map((way, index) => (
              <div
                key={way.title}
                className="grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-12 border-t border-ink/15 pt-10"
              >
                <div className="md:col-span-1">
                  <span className="font-serif text-3xl text-brass">
                    0{index + 1}
                  </span>
                </div>
                <div className="md:col-span-5">
                  <h3 className="font-serif text-3xl md:text-4xl text-ink leading-tight">
                    {way.title}
                  </h3>
                  <span className="block mt-3 eyebrow text-ink/40">
                    {way.detail}
                  </span>
                </div>
                <div className="md:col-span-6">
                  <p className="text-ink/70 leading-relaxed text-lg">
                    {way.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pourquoi Théris */}
      <section className="bg-midnight text-bone py-24 md:py-32 container-px">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div>
              <span className="eyebrow-brass">Pourquoi Théris</span>
              <h2 className="mt-6 font-serif text-4xl md:text-5xl leading-[1.1]">
                Un partenaire,
                <br />
                <span className="italic">pas un placement.</span>
              </h2>
              <p className="mt-8 text-mist leading-relaxed text-lg">
                Nos investisseurs ne sont pas des numéros. Ils participent
                à des projets concrets, suivis, expliqués. La relation
                prime sur la transaction.
              </p>
            </div>
            <ul className="space-y-5">
              {reasons.map((reason) => (
                <li
                  key={reason}
                  className="flex items-start gap-4 border-b border-bone/10 pb-5"
                >
                  <span className="font-serif text-brass mt-1">+</span>
                  <span className="text-bone/90">{reason}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Formulaire investisseur */}
      <section className="bg-bone py-24 md:py-32 container-px">
        <div className="max-w-5xl mx-auto">
          <div className="max-w-2xl mb-12">
            <span className="eyebrow-brass">Devenir partenaire</span>
            <h2 className="mt-6 font-serif text-4xl md:text-5xl text-ink leading-[1.1]">
              Parlons de votre stratégie.
            </h2>
            <p className="mt-6 text-ink/70 leading-relaxed text-lg">
              Quelques minutes pour nous présenter votre profil, votre
              capacité d'investissement et vos objectifs. On revient vers
              vous sous 48h ouvrables.
            </p>
          </div>
          <InvestorForm variant="light" />
        </div>
      </section>
    </>
  );
}
