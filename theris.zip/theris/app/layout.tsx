import type { Metadata } from "next";
import { Inter, Fraunces } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  display: "swap",
  axes: ["opsz", "SOFT"],
});

export const metadata: Metadata = {
  title: "Théris — Marchand de biens en Belgique",
  description:
    "Théris achète, rénove et vous vend ses propres biens. Accompagnement complet jusqu'à la remise des clés. Bruxelles, Belgique.",
  keywords: [
    "marchand de biens",
    "immobilier Belgique",
    "investissement immobilier",
    "Bruxelles",
    "rénovation",
  ],
  openGraph: {
    title: "Théris — Marchand de biens en Belgique",
    description:
      "Des biens choisis. Rénovés. Accompagnés. De la première visite à la remise des clés.",
    type: "website",
    locale: "fr_BE",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" className={`${inter.variable} ${fraunces.variable}`}>
      <body className="font-sans bg-bone text-ink">
        <Navbar />
        <main className="min-h-screen">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
