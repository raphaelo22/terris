import Link from "next/link";
import { Plus, Edit2 } from "lucide-react";
import { getAllBiens } from "@/lib/biens";
import { formatPrice } from "@/lib/utils";
import LogoutButton from "./LogoutButton";

export const dynamic = "force-dynamic";

export default function AdminPage() {
  const biens = getAllBiens();

  const counts = {
    total: biens.length,
    disponible: biens.filter((b) => b.statut === "disponible").length,
    reserve: biens.filter((b) => b.statut === "reserve").length,
    vendu: biens.filter((b) => b.statut === "vendu").length,
  };

  return (
    <div className="min-h-screen bg-bone">
      {/* Header admin */}
      <header className="bg-ink text-bone container-px py-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <span className="eyebrow-brass">Back-office</span>
            <h1 className="font-serif text-2xl mt-1">Gestion des biens</h1>
          </div>
          <LogoutButton />
        </div>
      </header>

      <main className="container-px py-12">
        <div className="max-w-7xl mx-auto space-y-10">
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white border border-ink/10 p-6">
              <span className="eyebrow text-ink/50">Total</span>
              <p className="mt-2 font-serif text-3xl text-ink">{counts.total}</p>
            </div>
            <div className="bg-white border border-ink/10 p-6">
              <span className="eyebrow text-ink/50">Disponible</span>
              <p className="mt-2 font-serif text-3xl text-brass">
                {counts.disponible}
              </p>
            </div>
            <div className="bg-white border border-ink/10 p-6">
              <span className="eyebrow text-ink/50">Réservé</span>
              <p className="mt-2 font-serif text-3xl text-mist">
                {counts.reserve}
              </p>
            </div>
            <div className="bg-white border border-ink/10 p-6">
              <span className="eyebrow text-ink/50">Vendu</span>
              <p className="mt-2 font-serif text-3xl text-ink/40">
                {counts.vendu}
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-between items-center">
            <h2 className="font-serif text-2xl text-ink">
              Tous les biens ({counts.total})
            </h2>
            <Link
              href="/admin/biens/nouveau"
              className="inline-flex items-center gap-2 bg-ink text-bone px-5 py-3 text-sm uppercase tracking-widest hover:bg-midnight transition"
            >
              <Plus size={16} /> Ajouter un bien
            </Link>
          </div>

          {/* Liste des biens */}
          <div className="bg-white border border-ink/10 overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-ink/5 text-ink/60">
                <tr>
                  <th className="px-6 py-4 text-left eyebrow font-medium">
                    Titre
                  </th>
                  <th className="px-6 py-4 text-left eyebrow font-medium">
                    Ville
                  </th>
                  <th className="px-6 py-4 text-left eyebrow font-medium">
                    Type
                  </th>
                  <th className="px-6 py-4 text-right eyebrow font-medium">
                    Prix
                  </th>
                  <th className="px-6 py-4 text-left eyebrow font-medium">
                    Statut
                  </th>
                  <th className="px-6 py-4 text-right eyebrow font-medium">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {biens.map((bien) => (
                  <tr
                    key={bien.id}
                    className="border-t border-ink/10 hover:bg-cream/30"
                  >
                    <td className="px-6 py-4 font-medium">{bien.titre}</td>
                    <td className="px-6 py-4 text-ink/70">{bien.ville}</td>
                    <td className="px-6 py-4 text-ink/70 capitalize">
                      {bien.type}
                    </td>
                    <td className="px-6 py-4 text-right font-serif">
                      {formatPrice(bien.prix)}
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`inline-block px-2 py-1 text-[0.65rem] uppercase tracking-widest ${
                          bien.statut === "disponible"
                            ? "bg-brass/20 text-brass-dark"
                            : bien.statut === "reserve"
                              ? "bg-mist/20 text-ink/70"
                              : "bg-ink/10 text-ink/50"
                        }`}
                      >
                        {bien.statut}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <Link
                        href={`/admin/biens/${bien.slug}`}
                        className="inline-flex items-center gap-2 text-ink/70 hover:text-brass transition"
                      >
                        <Edit2 size={14} /> Modifier
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bg-cream/50 border border-ink/10 p-6 text-sm text-ink/70 leading-relaxed">
            <p className="font-medium text-ink mb-2">Note :</p>
            <p>
              Cette interface permet de visualiser les biens. Pour ajouter,
              modifier ou supprimer un bien, éditez directement le fichier
              <code className="mx-1 px-2 py-0.5 bg-white border border-ink/10 font-mono text-xs">
                data/biens.json
              </code>
              à la racine du projet. Une interface complète d'édition
              peut être ajoutée en seconde phase si besoin.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
