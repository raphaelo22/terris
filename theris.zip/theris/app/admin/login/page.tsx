"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Logo from "@/components/ui/Logo";
import Button from "@/components/ui/Button";

export default function AdminLoginPage() {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });

      if (res.ok) {
        router.push("/admin");
        router.refresh();
      } else {
        setError("Mot de passe incorrect");
      }
    } catch (err) {
      setError("Erreur de connexion");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-ink flex items-center justify-center container-px">
      <div className="w-full max-w-md space-y-12">
        <div className="text-center">
          <Logo variant="light" />
        </div>

        <div className="space-y-3 text-center">
          <span className="eyebrow-brass">Espace privé</span>
          <h1 className="font-serif text-bone text-3xl">Connexion admin</h1>
          <p className="text-mist text-sm">
            Accès réservé à l'équipe Théris
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex flex-col gap-2">
            <label className="text-xs uppercase tracking-widest font-medium text-bone/60">
              Mot de passe
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoFocus
              required
              className="w-full bg-transparent border-b border-bone/30 py-3 px-0 text-bone focus:outline-none focus:border-brass transition-colors"
            />
            {error && <span className="text-red-400 text-xs">{error}</span>}
          </div>

          <Button
            type="submit"
            variant="outline-light"
            className={loading ? "opacity-60 cursor-wait w-full justify-center" : "w-full justify-center"}
          >
            {loading ? "Connexion…" : "Se connecter"}
          </Button>
        </form>
      </div>
    </div>
  );
}
