import type { Metadata } from "next";
import PropertyCard from "@/components/ui/PropertyCard";
import { getAllBiens } from "@/lib/biens";

export const metadata: Metadata = {
  title: "Nos biens disponibles · Théris",
  description:
    "Découvrez les biens immobiliers disponibles chez Théris. Maisons, appartements, terrains et immeubles de rapport en Belgique.",
};

export default function BiensPage() {
  const biens = getAllBiens();

  return (
    <>
      {/* En-tête de page */}
      <section className="bg-ink text-bone pt-40 pb-24 container-px">
        <div className="max-w-7xl mx-auto">
          <span className="eyebrow-brass">Notre sélection</span>
          <h1 className="mt-6 font-serif text-5xl md:text-6xl lg:text-7xl leading-[1.05]">
            Les biens
            <br />
            <span className="italic">à la une.</span>
          </h1>
          <p className="mt-8 text-mist text-lg leading-relaxed max-w-2xl">
            Chaque bien sur cette page nous appartient. Pas de mandat, pas
            d'intermédiaire. Vous traitez directement avec celui qui rénove
            et accompagne.
          </p>
        </div>
      </section>

      {/* Grille des biens */}
      <section className="bg-bone py-20 container-px">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
            {biens.map((bien) => (
              <PropertyCard key={bien.id} bien={bien} variant="light" />
            ))}
          </div>

          {biens.length === 0 && (
            <div className="py-32 text-center">
              <p className="font-serif text-2xl text-ink/60">
                Aucun bien disponible pour le moment.
              </p>
              <p className="mt-4 text-ink/60">
                Inscrivez-vous pour être prévenu(e) des prochaines opportunités.
              </p>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
