import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { getBienBySlug, getAllBiens } from "@/lib/biens";
import { formatPrice, formatSurface } from "@/lib/utils";
import ContactForm from "@/components/forms/ContactForm";

type Props = {
  params: { slug: string };
};

export async function generateStaticParams() {
  return getAllBiens().map((bien) => ({ slug: bien.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const bien = getBienBySlug(params.slug);
  if (!bien) return { title: "Bien introuvable · Théris" };

  return {
    title: `${bien.titre} · Théris`,
    description: bien.description.slice(0, 160),
  };
}

export default function BienDetailPage({ params }: Props) {
  const bien = getBienBySlug(params.slug);
  if (!bien) notFound();

  const isAvailable = bien.statut === "disponible";

  return (
    <>
      {/* Galerie en grand */}
      <section className="relative pt-20 bg-ink">
        <div className="container-px py-8">
          <Link
            href="/biens"
            className="inline-flex items-center gap-2 text-bone/60 hover:text-brass transition-colors text-sm uppercase tracking-widest"
          >
            <ArrowLeft size={16} /> Retour aux biens
          </Link>
        </div>

        <div className="relative h-[60vh] md:h-[80vh] w-full overflow-hidden">
          {bien.photos[0] && (
            <Image
              src={bien.photos[0]}
              alt={bien.titre}
              fill
              priority
              sizes="100vw"
              className="object-cover"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/30 to-transparent" />

          <div className="absolute bottom-0 left-0 right-0 container-px pb-12 md:pb-16 text-bone">
            <div className="max-w-7xl mx-auto">
              <span className="eyebrow-brass">{bien.ville}</span>
              <h1 className="mt-4 font-serif text-4xl md:text-6xl lg:text-7xl leading-[1.05] max-w-4xl">
                {bien.titre}
              </h1>
              {!isAvailable && (
                <span className="mt-6 inline-block bg-brass/20 border border-brass/40 text-brass px-4 py-2 text-xs uppercase tracking-widest">
                  {bien.statut === "reserve" ? "Réservé" : "Vendu"}
                </span>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Caractéristiques + description */}
      <section className="bg-bone py-20 md:py-28 container-px">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20">
            <div className="lg:col-span-7 space-y-10">
              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 border-y border-ink/15 py-8">
                <div>
                  <span className="eyebrow text-ink/50">Type</span>
                  <p className="mt-2 font-serif text-xl capitalize">
                    {bien.type}
                  </p>
                </div>
                <div>
                  <span className="eyebrow text-ink/50">Surface</span>
                  <p className="mt-2 font-serif text-xl">
                    {formatSurface(bien.surface)}
                  </p>
                </div>
                {bien.chambres && (
                  <div>
                    <span className="eyebrow text-ink/50">Chambres</span>
                    <p className="mt-2 font-serif text-xl">{bien.chambres}</p>
                  </div>
                )}
                <div>
                  <span className="eyebrow text-ink/50">Prix</span>
                  <p className="mt-2 font-serif text-xl text-brass">
                    {formatPrice(bien.prix)}
                  </p>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-6">
                <span className="eyebrow-brass">À propos du bien</span>
                <p className="font-serif text-2xl md:text-3xl leading-snug text-ink">
                  {bien.description}
                </p>
              </div>

              {/* Caractéristiques */}
              <div>
                <span className="eyebrow-brass">Caractéristiques</span>
                <ul className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                  {bien.caracteristiques.map((c) => (
                    <li
                      key={c}
                      className="flex items-start gap-3 border-t border-ink/10 pt-3"
                    >
                      <span className="text-brass mt-1.5 w-1.5 h-1.5 rounded-full bg-brass shrink-0" />
                      <span className="text-ink/80">{c}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Photos additionnelles */}
              {bien.photos.length > 1 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-8">
                  {bien.photos.slice(1).map((photo, i) => (
                    <div
                      key={i}
                      className="relative aspect-[4/3] overflow-hidden bg-ink/5"
                    >
                      <Image
                        src={photo}
                        alt={`${bien.titre} — vue ${i + 2}`}
                        fill
                        sizes="(max-width: 768px) 100vw, 50vw"
                        className="object-cover"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Formulaire */}
            <div className="lg:col-span-5">
              <div className="lg:sticky lg:top-32 bg-cream/50 border border-ink/10 p-8 md:p-10 space-y-6">
                <div>
                  <span className="eyebrow-brass">Ce bien vous intéresse ?</span>
                  <h2 className="mt-3 font-serif text-3xl text-ink leading-tight">
                    Demandez plus d'informations
                  </h2>
                  <p className="mt-3 text-ink/70 text-sm">
                    On vous recontacte rapidement pour organiser une visite
                    ou répondre à vos questions.
                  </p>
                </div>
                <ContactForm
                  variant="light"
                  bienRef={bien.titre}
                  defaultMessage={`Bonjour, je suis intéressé(e) par ${bien.titre} (${bien.ville}). Pouvons-nous échanger ?`}
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
