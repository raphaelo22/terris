import { NextResponse } from "next/server";
import { z } from "zod";
import { sendLeadEmail, formatLeadHtml } from "@/lib/email";

const schema = z.object({
  nom: z.string().min(2),
  email: z.string().email(),
  telephone: z.string().min(8),
  message: z.string().min(5),
  bienRef: z.string().optional(),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const data = schema.parse(body);

    const subjectPrefix = data.bienRef ? "[BIEN]" : "[CONTACT]";
    const subject = data.bienRef
      ? `${subjectPrefix} ${data.nom} — ${data.bienRef}`
      : `${subjectPrefix} ${data.nom}`;

    const html = formatLeadHtml(
      data.bienRef
        ? `🔑 Demande sur un bien : ${data.bienRef}`
        : "✉️ Nouveau message",
      {
        Nom: data.nom,
        Email: data.email,
        Téléphone: data.telephone,
        ...(data.bienRef && { "Bien référencé": data.bienRef }),
        Message: data.message,
      },
    );

    const result = await sendLeadEmail({
      subject,
      html,
      replyTo: data.email,
    });

    if (!result.success) {
      return NextResponse.json({ error: "Erreur d'envoi" }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Données invalides", details: error.errors },
        { status: 400 },
      );
    }
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
