import { NextResponse } from "next/server";
import { z } from "zod";
import { sendLeadEmail, formatLeadHtml } from "@/lib/email";

const schema = z.object({
  prenom: z.string().min(2),
  email: z.string().email(),
  telephone: z.string().min(8),
  budget: z.string(),
  epargne: z.string(),
  typeRecherche: z.string(),
  zoneRecherche: z.string(),
  timeline: z.string(),
  message: z.string().optional(),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const data = schema.parse(body);

    const html = formatLeadHtml("🏠 Nouveau lead acheteur", {
      Prénom: data.prenom,
      Email: data.email,
      Téléphone: data.telephone,
      Budget: data.budget,
      "Épargne disponible": data.epargne,
      "Type de bien": data.typeRecherche,
      "Zone souhaitée": data.zoneRecherche,
      Timeline: data.timeline,
      Message: data.message,
    });

    const result = await sendLeadEmail({
      subject: `[ACHETEUR] ${data.prenom} — ${data.budget}`,
      html,
      replyTo: data.email,
    });

    if (!result.success) {
      return NextResponse.json(
        { error: "Erreur d'envoi" },
        { status: 500 },
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Données invalides", details: error.errors },
        { status: 400 },
      );
    }
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
