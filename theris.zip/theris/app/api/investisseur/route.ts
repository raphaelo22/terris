import { NextResponse } from "next/server";
import { z } from "zod";
import { sendLeadEmail, formatLeadHtml } from "@/lib/email";

const schema = z.object({
  prenom: z.string().min(2),
  email: z.string().email(),
  telephone: z.string().min(8),
  montant: z.string(),
  objectif: z.string(),
  profil: z.string(),
  message: z.string().optional(),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const data = schema.parse(body);

    const html = formatLeadHtml("💼 Nouveau lead investisseur", {
      Prénom: data.prenom,
      Email: data.email,
      Téléphone: data.telephone,
      "Capacité d'investissement": data.montant,
      Profil: data.profil,
      Objectif: data.objectif,
      Message: data.message,
    });

    const result = await sendLeadEmail({
      subject: `[INVESTISSEUR] ${data.prenom} — ${data.montant}`,
      html,
      replyTo: data.email,
    });

    if (!result.success) {
      return NextResponse.json({ error: "Erreur d'envoi" }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Données invalides", details: error.errors },
        { status: 400 },
      );
    }
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
