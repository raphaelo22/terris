import type { Metadata } from "next";
import { Phone, Mail, MapPin, Clock } from "lucide-react";
import ContactForm from "@/components/forms/ContactForm";

export const metadata: Metadata = {
  title: "Contact · Théris",
  description:
    "Discutons de votre projet immobilier. Théris vous répond rapidement, sans engagement.",
};

const infos = [
  {
    icon: Phone,
    label: "Téléphone",
    value: "+32 (0)0 00 00 00 00",
    href: "tel:+32000000000",
  },
  {
    icon: Mail,
    label: "Email",
    value: "contact@theris.be",
    href: "mailto:contact@theris.be",
  },
  {
    icon: MapPin,
    label: "Adresse",
    value: "Bruxelles, Belgique",
  },
  {
    icon: Clock,
    label: "Horaires",
    value: "Lun – Sam · 9h – 19h",
  },
];

export default function ContactPage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-ink text-bone pt-40 pb-24 container-px">
        <div className="max-w-7xl mx-auto">
          <span className="eyebrow-brass">Contact</span>
          <h1 className="mt-6 font-serif text-5xl md:text-6xl lg:text-7xl leading-[1.05] max-w-4xl">
            Parlons de
            <br />
            <span className="italic">votre projet.</span>
          </h1>
          <p className="mt-8 text-mist text-lg leading-relaxed max-w-2xl">
            Que vous cherchiez un bien, vouliez investir, ou ayez simplement
            une question — on prend le temps de vous écouter et de vous
            répondre clairement.
          </p>
        </div>
      </section>

      {/* Contenu */}
      <section className="bg-bone py-24 md:py-32 container-px">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20">
            {/* Infos contact */}
            <div className="lg:col-span-5 space-y-12">
              <div>
                <span className="eyebrow-brass">Nous joindre</span>
                <h2 className="mt-4 font-serif text-3xl text-ink">
                  Plusieurs façons d'entrer en contact.
                </h2>
              </div>

              <ul className="space-y-8">
                {infos.map((info) => {
                  const Icon = info.icon;
                  const content = (
                    <div className="flex items-start gap-5">
                      <div className="w-10 h-10 rounded-full bg-ink/5 flex items-center justify-center flex-shrink-0">
                        <Icon size={18} className="text-brass" />
                      </div>
                      <div>
                        <span className="eyebrow text-ink/50 block mb-1">
                          {info.label}
                        </span>
                        <span className="text-ink text-lg">{info.value}</span>
                      </div>
                    </div>
                  );

                  return (
                    <li key={info.label}>
                      {info.href ? (
                        <a
                          href={info.href}
                          className="block hover:text-brass transition-colors"
                        >
                          {content}
                        </a>
                      ) : (
                        content
                      )}
                    </li>
                  );
                })}
              </ul>
            </div>

            {/* Formulaire */}
            <div className="lg:col-span-7">
              <div className="bg-cream/50 border border-ink/10 p-8 md:p-12 space-y-8">
                <div>
                  <span className="eyebrow-brass">Écrivez-nous</span>
                  <h2 className="mt-3 font-serif text-3xl text-ink">
                    Votre message
                  </h2>
                </div>
                <ContactForm variant="light" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
