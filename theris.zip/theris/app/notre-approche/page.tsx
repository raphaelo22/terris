import type { Metadata } from "next";
import Image from "next/image";
import Button from "@/components/ui/Button";

export const metadata: Metadata = {
  title: "Notre approche · Théris",
  description:
    "La méthode Théris : sélection, rénovation, présentation, accompagnement. 15 ans d'expérience au service de votre projet immobilier.",
};

const steps = [
  {
    number: "01",
    title: "Sélection",
    description:
      "Avant qu'un bien arrive sur ce site, nous l'avons étudié, négocié, acheté. Nous identifions des biens à fort potentiel — emplacement, structure, opportunité de valorisation. Notre métier, c'est de voir ce que les autres ne voient pas.",
    keypoints: [
      "Analyse du marché local",
      "Étude technique et juridique",
      "Négociation directe avec les vendeurs",
    ],
  },
  {
    number: "02",
    title: "Rénovation",
    description:
      "Nous orchestrons les travaux avec des artisans de confiance, sélectionnés sur le terrain au fil des années. Volumes, matériaux, finitions — chaque choix vise la qualité durable, pas le maquillage rapide.",
    keypoints: [
      "Pilotage chantier de bout en bout",
      "Mise aux normes énergétiques",
      "Choix de matériaux pérennes",
    ],
  },
  {
    number: "03",
    title: "Présentation",
    description:
      "Nous vous montrons le bien sans pression commerciale. Visite guidée, explication des choix de rénovation, transparence sur ce qui a été fait et ce qui reste. Vous repartez avec toutes les cartes en main.",
    keypoints: [
      "Visite sans rendez-vous artificiel",
      "Transparence totale sur les travaux",
      "Documentation technique complète",
    ],
  },
  {
    number: "04",
    title: "Accompagnement",
    description:
      "Notre engagement ne s'arrête pas à la signature. Nous vous mettons en relation avec nos partenaires de confiance — banques, notaires, artisans pour finitions complémentaires — et nous suivons chaque étape jusqu'à la remise des clés. Et souvent au-delà.",
    keypoints: [
      "Mise en relation banques et notaires",
      "Coordination des travaux complémentaires",
      "Suivi post-emménagement",
    ],
  },
];

export default function ApproachPage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-ink text-bone pt-40 pb-24 container-px">
        <div className="max-w-7xl mx-auto">
          <span className="eyebrow-brass">Notre approche</span>
          <h1 className="mt-6 font-serif text-5xl md:text-6xl lg:text-7xl leading-[1.05] max-w-4xl">
            Une méthode rodée par
            <br />
            <span className="italic">15 ans de terrain.</span>
          </h1>
          <p className="mt-8 text-mist text-lg leading-relaxed max-w-2xl">
            Théris n'a pas réinventé l'immobilier. Nous l'avons simplement
            recentré autour de ce qui compte : posséder, rénover, accompagner.
            Trois verbes, une méthode.
          </p>
        </div>
      </section>

      {/* Étapes détaillées */}
      <section className="bg-bone py-24 md:py-32 container-px">
        <div className="max-w-5xl mx-auto space-y-24 md:space-y-32">
          {steps.map((step, index) => (
            <div
              key={step.number}
              className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-16"
            >
              <div className="md:col-span-4">
                <span className="font-serif text-6xl md:text-7xl text-brass leading-none">
                  {step.number}
                </span>
                <h2 className="mt-6 font-serif text-3xl md:text-4xl text-ink leading-tight">
                  {step.title}
                </h2>
              </div>
              <div className="md:col-span-8 space-y-6">
                <p className="text-ink/80 text-lg leading-relaxed">
                  {step.description}
                </p>
                <ul className="space-y-3 pt-4 border-t border-ink/15">
                  {step.keypoints.map((kp) => (
                    <li
                      key={kp}
                      className="flex items-start gap-3 text-ink/70"
                    >
                      <span className="text-brass mt-2 w-1 h-1 rounded-full bg-brass shrink-0" />
                      <span>{kp}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA final */}
      <section className="bg-ink text-bone py-24 md:py-32 container-px">
        <div className="max-w-3xl mx-auto text-center space-y-10">
          <span className="eyebrow-brass">Prêt à passer à l'étape suivante ?</span>
          <h2 className="font-serif text-4xl md:text-6xl leading-[1.1]">
            Discutons de votre projet.
          </h2>
          <p className="text-mist text-lg leading-relaxed">
            Que vous cherchiez à acheter, à investir ou simplement à comprendre
            comment nous travaillons — on prend le temps qu'il faut.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button href="/biens" variant="secondary" icon>
              Voir nos biens
            </Button>
            <Button href="/contact" variant="outline-light" icon>
              Nous contacter
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
