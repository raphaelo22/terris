# Théris — Site web

Site web pour Théris, marchand de biens en Belgique.
Next.js 14 · Tailwind CSS · TypeScript · Framer Motion · Resend.

## Démarrer en local

```bash
cd apps/theris
npm install
cp .env.example .env.local   # puis remplir les variables
npm run dev
```

Le site sera accessible sur [http://localhost:3000](http://localhost:3000).

## Variables d'environnement

Dans `.env.local` :

```
RESEND_API_KEY=re_xxxxxxxxxxxx     # https://resend.com
EMAIL_TO=contact@theris.be          # destinataire des leads
EMAIL_FROM=site@theris.be           # expéditeur (vérifié sur Resend)
ADMIN_PASSWORD=changeme             # accès /admin
```

Si `RESEND_API_KEY` n'est pas configurée, les emails sont loggés dans la
console (mode développement).

## Structure

```
apps/theris/
├── app/
│   ├── page.tsx                    # Homepage
│   ├── biens/                      # Catalogue + fiches biens
│   ├── investisseurs/              # Page investisseurs
│   ├── notre-approche/             # Méthode Théris
│   ├── contact/                    # Contact
│   ├── admin/                      # Back-office (protégé)
│   └── api/                        # API routes (formulaires + admin)
├── components/
│   ├── layout/                     # Navbar, Footer
│   ├── sections/                   # Sections homepage
│   ├── ui/                         # Button, Logo, PropertyCard
│   └── forms/                      # Formulaires
├── data/
│   └── biens.json                  # Source de vérité des biens
├── lib/                            # utils, types, biens, email
└── public/                         # Assets statiques
```

## Gérer les biens

Éditer le fichier `data/biens.json`. Chaque bien a :

```json
{
  "id": "unique",
  "slug": "url-friendly-slug",
  "titre": "Maison à Bruxelles",
  "type": "maison|appartement|terrain|immeuble",
  "ville": "Bruxelles",
  "prix": 500000,
  "surface": 150,
  "chambres": 3,
  "sallesDeBain": 2,
  "description": "...",
  "caracteristiques": ["..."],
  "photos": ["url1", "url2"],
  "statut": "disponible|reserve|vendu",
  "miseEnAvant": true,
  "createdAt": "2025-10-15"
}
```

La page `/admin` (protégée par mot de passe) permet de visualiser
l'inventaire. L'édition se fait pour l'instant directement dans le
fichier JSON.

## Déploiement Vercel

1. Connecter le repo à Vercel.
2. Configurer les variables d'environnement.
3. Vercel build automatiquement à chaque push.

## Identité de marque

- **Couleurs** : `ink` (#0A1628), `bone` (#F5F1EA), `brass` (#B89968)
- **Typographies** : Fraunces (serif éditorial), Inter (sans-serif)
- **Ton** : direct, humain, professionnel — jamais "agence immobilière"

## Tests

```bash
npm run typecheck    # Vérification TypeScript
npm run build        # Build de production
```
